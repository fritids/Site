<?php 
include 'core/init.php';
protect_page();
include 'includes/overall/header.php'; 

if (isset($_GET['username']) === true && empty($_GET['username']) === false) {
    $username       = $_GET['username'];
    
    if (user_exists($username) === true) {
        $user_id        = user_id_from_username($username);
        $profile_data   = user_data($user_id, 'username', 'first_name', 'last_name', 'email', 'city_id', 'profile');
    ?>
        
        <h1><?php echo $profile_data['username']; ?>'s profile</h1>
		<?php
		if (empty($profile_data['profile']) === false) {
            echo '<img src="' . $profile_data['profile'] . '" alt="' . $profile_data['username'] . '\'s Profile Image">';
        }
		?>
		<p><?php echo $profile_data['first_name'] . " " . $profile_data['last_name'] . "<br>" . $profile_data['email'] . "<br>" . city_from_city_id($profile_data['city_id']); ?></p>
    <?php
    } else {
        echo 'Sorry, that user doesn\'t exist!';
    }
} else {
    header('Location: index.php');
    exit();
}

include 'includes/overall/footer.php'; ?>
