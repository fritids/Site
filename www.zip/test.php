<?php
include 'core/init.php';

    $input = $_GET['input'];
    
    $len = strlen($input);
    $query = mysql_query("SELECT `city_`.`id`, `city_`.`city_name_ru` FROM `city_` WHERE `city_`.`city_name_ru` LIKE '".$_GET['input']."%' LIMIT 0, 10");

    $aResults = array();
    if ($len)
    {
        $i = 0;
        while (($row = mysql_fetch_assoc($query)) !== false) {
             $cname = $row['city_name_ru'];
                $i++;
                $aResults[] = array( "id"=>($i) ,"value"=>$cname, "info"=>$row['city_name_ru'] );
        }
    }
	
	
	
	
	
	header ("Expires: Mon, 26 Jul 1997 05:00:00 GMT"); // Date in the past
	header ("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT"); // always modified
	header ("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
	header ("Pragma: no-cache"); // HTTP/1.0
	
	
	

		header("Content-Type: application/json; charset=UTF-8");
	
		echo "{\"results\": [";
		$arr = array();
		for ($i=0;$i<count($aResults);$i++)
		{
			$arr[] = "{\"id\": \"".$aResults[$i]['id']."\", \"value\": \"".$aResults[$i]['value']."\", \"info\": \"\"}";
		}
		echo implode(", ", $arr);
		echo "]}";
	
?>