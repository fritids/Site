<?php
include 'core/init.php';
echo $_GET['we'];
$query = mysql_query("SELECT * FROM `city_` WHERE `city_name_ru` LIKE '".$_GET['we']."%'");
        $i = 0;
        while (($row = mysql_fetch_assoc($query)) !== false) {
             $cname = $row['city_name_ru'];
                echo $cname;
        }
?>