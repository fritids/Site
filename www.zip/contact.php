<?php 
include 'core/init.php';
include 'includes/overall/header.php'; 
?>
<h1>Contact</h1>
<p>Contact details.</p>

<?php include 'includes/overall/footer.php'; ?>
