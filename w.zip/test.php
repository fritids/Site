<?php
if (false || true) {
	echo "true";
} else {
    echo "false";
}
?>