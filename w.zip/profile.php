<?php 
include 'core/init.php';
protect_page();
include 'includes/overall/header.php'; 

if (isset($_GET['username']) === true && empty($_GET['username']) === false) {
    $username       = $_GET['username'];
    
    if (user_exists($username) === true) {
        $user_id        = user_id_from_username($username);
        $profile_data   = user_data($user_id, 'username', 'first_name', 'last_name', 'email', 'city_id', 'profile');
    ?>
    <script src="http://code.jquery.com/jquery-1.8.2.js"></script>
        
    <script language="JavaScript" type="text/javascript">
    <!--
    function add_friend(fid, uid) {
        $("#friend").html('<img src="images/loader.gif"/>').show();
        var url = "friends.php";
        $.post(url, { user: uid, friend: fid, func: 'add' } ,function(data) {
            $("#friend").html(data).show();
        });
    }
    //-->
    </script>
        <h1><?php echo $profile_data['username']; ?>'s profile</h1>
		<?php
		if (empty($profile_data['profile']) === false) {
            echo '<img class="profile_img" src="' . $base_url . $profile_data['profile'] . '" alt="' . $profile_data['username'] . '\'s Profile Image">';
        }
		?>
		<p><?php echo $profile_data['first_name'] . " " . $profile_data['last_name'] . "<br>" . $profile_data['email'] . "<br><a href=\"" . $base_url . "city/" . $profile_data['city_id'] . "\">" . city_from_city_id($profile_data['city_id']) . "</a>"; ?></p>
		
        <?php 
        if ($user_id !== $session_user_id){
            if (is_friend($user_id , $session_user_id, 0) === true) {
                echo "<p>Friend!</p>";
            } else if (is_friend($user_id , $session_user_id, 1) === true) {
                echo "<p>Request send!</p>";
            } else {
                echo '<p id="friend"><a href="#" onclick="javascript: add_friend(' . $session_user_id . ', ' . $user_id . ')">Add friend</a></p>';
            }
        }
        ?>
        
<?php
    } else {
        echo 'Sorry, that user doesn\'t exist!';
    }
} else {
    header('Location: index.php');
    exit();
}

include 'includes/overall/footer.php'; 
?>
