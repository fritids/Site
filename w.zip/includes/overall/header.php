<!doctype html>
<html>
<?php include 'includes/head.php'; ?>
<body>
    <section id="conteiner">
	<?php include 'includes/header.php'; ?>
		<?php include 'includes/aside.php'; ?>
        <section id="content">