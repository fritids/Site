<footer>
    &copy; FloopyMan 2012. All rights reserved.
</footer>
