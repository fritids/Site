<nav>
    <ul>
        <li><a href="index.php">Index.php</a></li>
        <li><a href="login.php">Login.php</a></li>
        <li><a href="logout.php">Logout.php</a></li>
        <li><a href="downloads.php">Downloads.php</a></li>
        <li><a href="forum.php">Forum.php</a></li>
        <li><a href="contact.php">Contact.php</a></li>
    </ul>
</nav>
