<head>
    <title>WELCOME!!!</title>
    
    <meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
    <link rel="stylesheet/less" type="text/css" href="<?php echo $base_url; ?>css/screen.less">
    <script src="<?php echo $base_url; ?>js/less-1.3.1.min.js" type="text/javascript"></script>
    
</head>
