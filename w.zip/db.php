<style>
.people_cell a {
color: #2B587A;
text-decoration: none;
cursor: pointer;
}
user agent stylesheeta:-webkit-any-link {
color: -webkit-link;
text-decoration: underline;
cursor: auto;
}
.people_cell .ava {
display: block;
width: 50px;
height: 50px;
margin: 0px 8px;
padding-bottom: 6px;
}
img {
border: 0px;
}
img[Attributes Style] {
width: 50px;
height: 50px;
}
img {
display: inline-block;
}
.fl_l {
float: left;
}
.people_cell {
width: 66px;
overflow: hidden;
padding: 6px 0px;
text-align: center;
}
</style>
<div class="fl_l people_cell">
  <a class="ava" href="/narmulka">
    <img width="50" height="50" src="http://cs410817.userapi.com/u2703992/e_7675d5a8.jpg">
  </a>
  <div class="name_field">
    <a href="/narmulka" exuser="true">
      Наталья<br>
      <small>Булавкова</small>
    </a>
  </div>
</div>

<div class="fl_l people_cell">
  <a class="ava" href="/narmulka" onclick="return nav.go(this, event, {cl_id: 2703992})" onmouseover="vkPopupAvatar('2703992',this)" onmouseout="vkHidePhoto();">
    <img width="50" height="50" src="http://cs410817.userapi.com/u2703992/e_7675d5a8.jpg">
  </a>
  "<div class='name_field'><a href='" . $base_url . $row['username'] . "'>" . $row['first_name'] . "<br><small>" . $row['last_name'] . "</small>
</a>
  </div>
</div>
<div class="fl_l people_cell">
  <a class="ava" href="/narmulka" onclick="return nav.go(this, event, {cl_id: 2703992})" onmouseover="vkPopupAvatar('2703992',this)" onmouseout="vkHidePhoto();">
    <img width="50" height="50" src="http://cs410817.userapi.com/u2703992/e_7675d5a8.jpg">
  </a>
  <div class="name_field">
    <a href="/narmulka" exuser="true">
      Наталья<br>
      <small>Булавкова</small>
    </a>
  </div>
</div>
