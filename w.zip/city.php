<?php
include 'core/init.php';
protect_page();
include 'includes/overall/header.php';
$cityID = $_GET['city'];
?>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>

<h1><?php echo city_from_city_id($cityID, 'true'); ?></h1>
<?php
if (city_info($cityID) === false){
    echo '<div class="city_info">Add info</div>';
} else {
?><div class="city_info"><h1>Information</h1><?php echo city_info($cityID); ?></div><br><?php
}
?>
<div class="sight">
    <h1>Sights</h1>
    <div>
        <ul>
            <?php echo city_sights($cityID, 5); ?>
        </ul>
  </div>
</div><br>
<div class="users">
    <h1>Users</h1>
    <ul>
        <?php echo city_users($cityID, 5); ?>
    </ul>
</div>
<?php
include 'includes/overall/footer.php';
?>
