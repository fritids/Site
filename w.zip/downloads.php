<?php 
include 'core/init.php';
protect_page();
include 'includes/overall/header.php'; 
?>
<h1>Downloads</h1>
<p>Just a template.</p>

<?php include 'includes/overall/footer.php'; ?>
