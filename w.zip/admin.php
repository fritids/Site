<?php 
include 'core/init.php';
protect_page();
admin_protect();
include 'includes/overall/header.php'; 
?>
<h1>Admin</h1>
<p>Admin page.</p>

<?php include 'includes/overall/footer.php'; ?>
